#ifndef ControleH
#define ControleH
//-------------------------------------------------------------------
#include "InterfaceUsuario.h"
#include "Equacao2Grau.h"
class Controle
{
private:

public:
	Controle();
	~Controle();
	void controlarExecucao(void);
};

//-------------------------------------------------------------------
#endif