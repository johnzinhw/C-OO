#ifndef InterfaceUsuarioH
#define InterfaceUsuarioH
//------------------------------------------------------------------
#include <iostream>
using namespace std;
#include <string>

class InterfaceUsuario
{
private:

public:
	InterfaceUsuario();
	~InterfaceUsuario();

	void obterCoeficientes(int[3]);
	void mostrarRaizes(double, double);

};

//------------------------------------------------------------------
#endif