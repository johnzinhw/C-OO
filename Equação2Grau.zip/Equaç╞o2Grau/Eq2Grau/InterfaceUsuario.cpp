#include "InterfaceUsuario.h"

//-----------------------------------------------------------------
InterfaceUsuario::InterfaceUsuario()
{
}

InterfaceUsuario::~InterfaceUsuario()
{
}

void InterfaceUsuario::obterCoeficientes(int CoeficientesEntrados[2])
{
	for (int i = 0; i < 3; i++)
	{
		cout << "Entre com o coeficiente " << i + 1 << ": " ;
		cin >> CoeficientesEntrados[i];
	}
}
void InterfaceUsuario::mostrarRaizes(double ARaiz1, double ARaiz2)
{
	cout << "-----------------------------------------------" << endl;
	cout << "o valor de X1 �: " << ARaiz1 << endl;
	cout << "o valor de X2 �: " << ARaiz2 << endl;
	system("pause");
}