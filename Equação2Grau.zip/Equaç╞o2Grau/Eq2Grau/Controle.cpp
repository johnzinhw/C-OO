#include "Controle.h"

//-------------------------------------------------------------------
Controle::Controle()
{
}

Controle::~Controle()
{
}
void Controle::controlarExecucao(void)
{
	InterfaceUsuario iu;
	Equacao2Grau	 eq2grau;

	int OsCoeficientes[3] = {0, 0, 0};
	double AsRaizes[2] = {0, 0};

	iu.obterCoeficientes(OsCoeficientes);
	
	eq2grau.calcularRaiz1(OsCoeficientes[0], OsCoeficientes[1], OsCoeficientes[2]);
	eq2grau.obterRaizes(AsRaizes);
	iu.mostrarRaizes(AsRaizes[0], AsRaizes[1]);
}
