#include "Equacao2Grau.h"

//-------------------------------------------------------------------
Equacao2Grau::Equacao2Grau()
{
	for (int i = 0; i < 2; ++i)
		ARaiz[i] = 0.0;
}

Equacao2Grau::~Equacao2Grau()
{
}

void Equacao2Grau::calcularRaiz1(int A, int B, int C)
{
	int Delta = 0;
	
	Delta = ((B*B) - 4 * (A*C));
	
	ARaiz[0] = ((-B) + (sqrt(Delta))) / (2 * A);
	ARaiz[1] = ((-B) - (sqrt(Delta))) / (2 * A);
}

void Equacao2Grau::obterRaizes(double AsRaizes[2])
{
	AsRaizes[0] = ARaiz[0];
	AsRaizes[1] = ARaiz[1];
}