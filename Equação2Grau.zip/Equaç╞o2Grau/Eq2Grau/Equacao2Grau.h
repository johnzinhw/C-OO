#ifndef Equacao2GrauH
#define Equacao2GrauH
//------------------------------------------------------------------
#include <iostream>
using namespace std;
#include <string>

class Equacao2Grau
{
private:
	double ARaiz[2];
public:
	Equacao2Grau();
	~Equacao2Grau();

	void calcularRaiz1(int, int, int);
	void obterRaizes(double[2]);
};
//------------------------------------------------------------------
#endif