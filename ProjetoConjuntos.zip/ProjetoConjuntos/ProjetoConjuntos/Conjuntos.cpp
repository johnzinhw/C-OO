#include "Conjuntos.h"

Conjuntos::Conjuntos()
{

}
Conjuntos::~Conjuntos()
{

}