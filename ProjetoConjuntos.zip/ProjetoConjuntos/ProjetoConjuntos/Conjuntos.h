#include <iostream>
using namespace std;
#include <string>

class Conjuntos
{
private:
	
public:
	Conjuntos();
	~Conjuntos();	
};