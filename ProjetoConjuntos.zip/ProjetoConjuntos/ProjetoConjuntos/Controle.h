#include <iostream>
using namespace std;
#include <string>
#include "InterfaceUsuario.h"
#include "Conjuntos.h"

class Controle
{
private:
public:
	Controle();
	~Controle();
};