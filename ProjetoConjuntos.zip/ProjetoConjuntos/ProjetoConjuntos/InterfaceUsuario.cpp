#include "InterfaceUsuario.h"

InterfaceUsuario::InterfaceUsuario()
{

	
}
InterfaceUsuario::~InterfaceUsuario()
{

}