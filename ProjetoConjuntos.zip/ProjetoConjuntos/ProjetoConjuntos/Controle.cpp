#include "Controle.h"

Controle::Controle()
{

}
Controle::~Controle()
{

}

