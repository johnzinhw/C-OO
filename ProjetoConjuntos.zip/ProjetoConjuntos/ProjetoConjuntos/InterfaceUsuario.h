#include <iostream>
using namespace std;
#include <string>

class InterfaceUsuario
{
private:
	
public:
	InterfaceUsuario();
	~InterfaceUsuario();
};