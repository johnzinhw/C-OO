#include "InterfaceUsuario.h"

InterfaceUsuario::InterfaceUsuario()
{

}

InterfaceUsuario::~InterfaceUsuario()
{

}
void InterfaceUsuario::obterEntrada(int ValoresEntrados[2])
{
	for (int i = 0; i < 2; ++i)
	{
		cout << "Entre com o numero " << i + 1 << ": ";
		cin >> ValoresEntrados[i];
	}
}

void InterfaceUsuario::mostrarResultado(int OResuldado)
{
	cout << "------------------------------------" << endl;
	cout << "O resultado da soma �: " << OResuldado << endl;
	cout << "------------------------------------" << endl;

}