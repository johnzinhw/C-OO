#ifndef InterfaceUsuarioH
#define InterfaceUsuarioH
//---------------------------------------------------------------------------------------------
#include <iostream>
using namespace std;
#include <string>

class InterfaceUsuario
{
private:
public:
	InterfaceUsuario(); //Construtor "default" (padrao)
	~InterfaceUsuario(); //Destrutor
	void obterEntrada(int[2]);
	void mostrarResultado(int);



};

//---------------------------------------------------------------------------------------------
#endif