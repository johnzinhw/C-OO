#ifndef ControleH
#define ControleH
//---------------------------------------------------------------------------------------------
#include "InterfaceUsuario.h"
#include "Somador.h"

class Controle
{
private:
public:
	Controle(); //Construtor "default" (padrao)
	~Controle(); //Destrutor
	void controlarExecucao(void);



};

//---------------------------------------------------------------------------------------------
#endif