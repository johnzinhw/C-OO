#ifndef SomadorH

#define SomadorH
//-------------------------------------------
#include <iostream>
using namespace std;
#include <string>

class Somador
{
private:
public:
	Somador();
	~Somador();
	int somar2Numeros(int, int);
};


//-------------------------------------------
#endif
