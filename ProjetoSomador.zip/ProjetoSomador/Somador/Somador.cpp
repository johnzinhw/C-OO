#include "Somador.h"
Somador::Somador()
{

}
Somador::~Somador()
{

}

int Somador::somar2Numeros(int Numero1, int Numero2)
{
	int ASoma = 0;
	ASoma = Numero1 + Numero2;
	return ASoma;
}