#include "Controle.h"

Controle::Controle()
{


}

Controle::~Controle()
{

}
void Controle::controlarExecucao(void)
{
	InterfaceUsuario iu;
	Somador     somador;

	int osValoresEntrados[2] = { 0, 0 };
	int OResultado = 0;

	iu.obterEntrada(osValoresEntrados);
	OResultado = somador.somar2Numeros(osValoresEntrados[0], osValoresEntrados[1]);
	iu.mostrarResultado(OResultado);
	

}