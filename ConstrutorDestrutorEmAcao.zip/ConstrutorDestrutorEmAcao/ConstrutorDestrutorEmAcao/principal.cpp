#include <iostream>
using namespace std;
#include <string>

class Arvore
{
private:
	string NomeDaArvore;
	double IdadeDaArvore, AlturaDaArvore;

public:
	Arvore();
	~Arvore();
};

int main(int argc, char * argv)
{
	Arvore a1;
	Arvore a2;

	return 0;
}

Arvore::Arvore()
{
	NomeDaArvore = "Pereira";
	IdadeDaArvore = 2.6;
	AlturaDaArvore = 1.85;
	cout << " Passando pelo construtor" << endl;
}

Arvore::~Arvore()
{
	cout << "Passando pelo destrutor" << endl;
}