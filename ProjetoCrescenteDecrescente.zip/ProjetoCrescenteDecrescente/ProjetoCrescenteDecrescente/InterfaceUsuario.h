#include <iostream>
using namespace std;
#include <string>

class InterfaceUsuario
{
private:
	string Palavras[10];
public:
	InterfaceUsuario();
	~InterfaceUsuario();
	int menuBasico(void);
	void lerValores(int[10]);
	void mostrarResultado(int[10]);
	void saiApp(void);
	int seDefault(void);
};