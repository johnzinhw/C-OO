#include <iostream>
using namespace std;
#include <string>

class NumerosInteiros
{
private:
	int ValoresFinal[10];
public:
	NumerosInteiros();
	~NumerosInteiros();
	void colocarEmOrdemCrescente(int[]);
	void colocarEmOrdemDecrescente(int[]);
};