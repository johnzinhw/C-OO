#include "NumerosInteiros.h"

NumerosInteiros::NumerosInteiros()
{

}
NumerosInteiros::~NumerosInteiros()
{

}
void NumerosInteiros::colocarEmOrdemCrescente(int Valores[])
{
	int aux;
	for (int i = 0; i < 10; i++)
	{
		for (int j = 0; j < 9; j++)
		{

			if (Valores[j]> Valores[j + 1])
			{
				aux = Valores[j + 1];
				Valores[j + 1] = Valores[j];
				Valores[j] = aux;

			}
		}
	}
	for (int cont = 0; cont < 10; cont++)
	{
		ValoresFinal[cont] = Valores[cont];
	}
}
void NumerosInteiros::colocarEmOrdemDecrescente(int Valores[])
{
	int aux;
	for (int i = 0; i < 10; i++)
	{
		for (int j = 0; j < 9; j++)
		{

			if (Valores[j]< Valores[j + 1])
			{
				aux = Valores[j + 1];
				Valores[j + 1] = Valores[j];
				Valores[j] = aux;

			}
		}
	}
	for (int cont = 0; cont < 10; cont++)
	{
		ValoresFinal[cont] = Valores[cont];
	}

}
