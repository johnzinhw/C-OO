#include "InterfaceUsuario.h"
InterfaceUsuario::InterfaceUsuario()
{

	Palavras[0] = "primeiro";
	Palavras[1] = "segundo";
	Palavras[2] = "terceiro";
	Palavras[3] = "quarto";
	Palavras[4] = "quinto";
	Palavras[5] = "sexto";
	Palavras[6] = "setimo";
	Palavras[7] = "oitavo";
	Palavras[8] = "nono";
	Palavras[9] = "decimo";

}
InterfaceUsuario::~InterfaceUsuario()
{

}
int InterfaceUsuario::menuBasico()
{
	int Opcao;
	system("cls");
	cout << " 1 - Ordenar de forma crescente." << endl;
	cout << " 2 - Ordenar de forma decrescente." << endl;
	cout << " 3 - Sair." << endl;
	cout << " Sua opcao : ";
	cin >> Opcao;
	return Opcao;
}
void InterfaceUsuario::lerValores(int Valores[])
{
	for (int i = 0; i < 10; i++)
	{
		cout << "Insira o " << Palavras[i] << " valor : ";
		cin >> Valores[i];
	}
	system("cls");
}
void InterfaceUsuario::mostrarResultado(int Valores[])
{
	for (int i = 0; i < 10; i++)
	{
		cout << " Em ordem: " << Valores[i] << endl;
	}
	system("pause");
}

void InterfaceUsuario::saiApp(void)
{
	cout << "SAINDO!" << endl;
	system("pause");
}

int InterfaceUsuario::seDefault(void)
{
	int Valor;
	cout << "OPCAO INVALIDA! ENTRE APENAS COM 1-2-3" << endl;
	cout << " Sua opcao : ";
	cin >> Valor;
	return Valor;
}

