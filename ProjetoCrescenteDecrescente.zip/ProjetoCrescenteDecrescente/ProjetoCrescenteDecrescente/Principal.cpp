#include "Controle.h"

int main(int argc, char * argv)
{
	Controle con;
	con.gerenciarExecucao();
	return 0;
}