#include "Controle.h"
Controle::Controle()
{

}
Controle::~Controle()
{

}
void Controle::gerenciarExecucao(void)
{
	int Valores[10];
	int Escolha;
	InterfaceUsuario IU;
	NumerosInteiros NI;
	Escolha = IU.menuBasico();
	do
	{
		Escolha = IU.menuBasico();
		switch (Escolha)
		{
		case 1:
			IU.lerValores(Valores);
			NI.colocarEmOrdemCrescente(Valores);
			IU.mostrarResultado(Valores);			
			break;
		case 2:
			IU.lerValores(Valores);			
			NI.colocarEmOrdemDecrescente(Valores);
			IU.mostrarResultado(Valores);			
			break;
		case 3:
			IU.saiApp();
			break;
		default:
			Escolha = IU.seDefault();
			break;
		}
	} while (Escolha != 3);
}