#include <iostream>
using namespace std;
#include <string>

class VerificadorPalavrasPalindromas
{
private:
	char palavra[10];
public:
	VerificadorPalavrasPalindromas();
	~VerificadorPalavrasPalindromas();
	char verificarPalindromas(char[]);
};
int main(int argc, char *argv[])
{
	char Palavra[10];
	char Resposta[10];
	VerificadorPalavrasPalindromas vfp;
	cout << "Digite uma palavra: " << endl;
	cin >> Palavra;
	strcpy_s (Resposta,vfp.verificarPalindromas(Palavra));
	return 0;
}
VerificadorPalavrasPalindromas::VerificadorPalavrasPalindromas()
{
	
}
VerificadorPalavrasPalindromas::~VerificadorPalavrasPalindromas()
{

}
char VerificadorPalavrasPalindromas::verificarPalindromas(char Palavra[])
{
	int i = 0, j = 5, cont = 0;
	char Resposta[10];
	while (i <= 5)
	{
		if (Palavra[i] = Palavra[j])
		{
			cont += 1;
		}
		j -= 1;
	}
	if (cont = 5)
	{
		strcpy_s (Resposta,"Palindroma");	
	}
	if (cont < 5)
	{
		strcpy_s (Resposta, "NaoPalindroma");
	}
	return Resposta[10];
}