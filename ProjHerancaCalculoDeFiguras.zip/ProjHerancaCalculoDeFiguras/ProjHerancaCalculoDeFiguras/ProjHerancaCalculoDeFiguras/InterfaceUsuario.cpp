#include "InterfaceUsuario.h"

InterfaceUsuario::InterfaceUsuario()
{
	Lados[0] = "primeiro lado: ";
	Lados[1] = "segundo lado: ";
	Lados[2] = "terceiro lado: ";
}

InterfaceUsuario::~InterfaceUsuario()
{

}
int InterfaceUsuario::escolherFigura(void)
{
	int Escolha;
	system("cls");
	cout << "1- Circulo "<<endl;
	cout << "2- Retangulo" << endl;;
	cout << "3- Triangulo" << endl;
	cout << "4- Sair" << endl;
	cout << "Sua opcao: ";
	cin >> Escolha;
	return Escolha;
}
float InterfaceUsuario::preencherdadosCircu(void)
{
	float Raio;
	system("cls");
		cout << "CIRCULO " << endl;
		cout << "insira o raio da circuferencia "<<endl;
		cout << "Raio : ";
		cin >> Raio;
		return Raio;
}
void InterfaceUsuario::preencherdadosRet(float Ladosret[2])
{
	system("cls");
	cout << "RETANGULO" << endl;
	cout << "Comprimento do retangulo "<<endl;
	cout << "Comprimento : ";
	cin >> Ladosret[0];
	cout << "Largura do retangulo" << endl;
	cout << "Largura : ";
	cin >> Ladosret[1];
}
void InterfaceUsuario::preencherosdadosTri(float LadosTri[3])
{
	system("cls");
	cout << "TRIANGULO" << endl;
	for (int i = 0; i < 3; i++)
	{
		cout << " insira o valor do " << Lados[i];
		cin >> LadosTri[i];
	}

}
void InterfaceUsuario::mostrarResultado(float Resultado[2])
{
	system("cls");
	cout << "O valor da area : " << Resultado[0] << endl;
	cout << "O valor do perimetro : " << Resultado[1] << endl;
	system("pause");
}