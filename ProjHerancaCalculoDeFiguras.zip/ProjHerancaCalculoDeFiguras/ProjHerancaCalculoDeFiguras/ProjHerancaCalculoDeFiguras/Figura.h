#ifndef FiguraH
#define FiguraH
//-------------------------------------------------------
#include <iostream>
using namespace std;
#include <string>

class Figura
{
private:
	double Area;
	double Perimetro;
	string NomeDaFigura;
	string UnidadeDeEngenharia;
public:
	Figura();
	~Figura();
protected:
	void setAreaEPeri(float[]);
	void setFigura(string);

};
//-----------------------------------------------------------
#endif