#include "Figura.h"

Figura::Figura()
{
	Area = 0.0;
	Perimetro = 0.0;
	NomeDaFigura = "";
	UnidadeDeEngenharia = "";
}

Figura::~Figura()
{

}
void Figura::setAreaEPeri(float areaperi[2])
{
	Area = areaperi[0];
	Perimetro = areaperi[1];
}
void Figura::setFigura(string tipo)
{
	NomeDaFigura = tipo;
}

