#include "Triangulo.h"

Triangulo::Triangulo()
{

}

Triangulo::~Triangulo()
{

}
void Triangulo::calcularTriangulo(float LadosDoTri[3], float AreaPeri[2])
{
	string tipo = "Triangulo";
	float semiP = 0.0, aux = 0.0;
	semiP = (LadosDoTri[0] + LadosDoTri[1] + LadosDoTri[2]) / 2;
	aux = semiP*(semiP - LadosDoTri[0])*(semiP - LadosDoTri[1])*(semiP - LadosDoTri[2]);
	AreaPeri[0] = sqrt(aux);
	AreaPeri[1] = semiP * 2;
	setAreaEPeri(AreaPeri);
	setFigura(tipo);
}
