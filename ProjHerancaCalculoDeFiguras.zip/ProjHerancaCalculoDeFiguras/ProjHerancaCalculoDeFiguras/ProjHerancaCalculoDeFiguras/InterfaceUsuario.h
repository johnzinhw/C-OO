#ifndef InterfaceUsuarioH
#define InterfaceUsuarioH
//-------------------------------------------------------------
#include <iostream>
using namespace std;
#include <string>

class InterfaceUsuario
{
private:
	string Lados[3];
public:
	InterfaceUsuario();
	~InterfaceUsuario();
	void preencherosdadosTri(float[]);
	void preencherdadosRet(float[]);
	float preencherdadosCircu(void);
	int escolherFigura(void);
	void mostrarResultado(float[]);
};
//--------------------------------------------------------------
#endif