#include "Retangulo.h"

Retangulo::Retangulo()
{

}

Retangulo::~Retangulo()
{

}
void Retangulo::calcularRet(float LadosDoTri[2],float AreaPeri[2])
{
	string tipo = "Retangulo";
	AreaPeri[0] = LadosDoTri[0] * LadosDoTri[1];
	AreaPeri[1] = (LadosDoTri[0] * 2) + (LadosDoTri[1] * 2);
	setAreaEPeri(AreaPeri);
	setFigura(tipo);
}