#ifndef CirculoH
#define CirculoH
//------------------------------------------------------
#define PI 3.14
#include"Figura.h"

class Circulo : public Figura
{
private:

public:
	Circulo();
	~Circulo();
	void calcularArea(float,float[]);
};
//---------------------------------------------------------
#endif