#ifndef RetanguloH
#define RetanguloH
//-----------------------------------------------

#include "Figura.h"

class Retangulo : public Figura
{
private:

public:
	Retangulo();
	~Retangulo();
	void calcularRet(float[],float[]);
};
//---------------------------------------------------
#endif;