#ifndef ControleH
#define ControleH
//------------------------------------------------

#include"Circulo.h"
#include"Retangulo.h"
#include"Triangulo.h"
#include "InterfaceUsuario.h"

class Controle
{
private:

public:
	Controle();
	~Controle();
	void gerenciarExecucao(void);

};

//------------------------------------------------
#endif;