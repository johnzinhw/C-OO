#include "Circulo.h"

Circulo::Circulo()
{

}

Circulo::~Circulo()
{

}
void Circulo::calcularArea(float Raioc,float areaperi[2])
{
	string tipo = "circulo";
	areaperi[0] = PI*(Raioc*Raioc);
	areaperi[1] = 2 * PI*Raioc;
	setAreaEPeri(areaperi);
	setFigura(tipo);
}
