#include "Controle.h"

Controle::Controle()
{

}

Controle::~Controle()
{

}

void Controle::gerenciarExecucao(void)
{
	float Ladosdotri[3], LadosdoRet[2], AreaPerimetro[2];
	float Raio;
	int desicao;
	InterfaceUsuario IU;
	Retangulo ret;
	Triangulo tria;
	Circulo cir;
	Figura fg;
	do
	{
		desicao = IU.escolherFigura();
		switch (desicao)
		{
			case 1 :
				Raio = IU.preencherdadosCircu();
				cir.calcularArea(Raio, AreaPerimetro);
				IU.mostrarResultado(AreaPerimetro);
				break;
			case 2 :
				IU.preencherdadosRet(LadosdoRet);
				ret.calcularRet(LadosdoRet, AreaPerimetro);
				IU.mostrarResultado(AreaPerimetro);
				break;
			case 3 :
				IU.preencherosdadosTri(Ladosdotri);
				tria.calcularTriangulo(Ladosdotri, AreaPerimetro);
				IU.mostrarResultado(AreaPerimetro);
				break;
			case 4 :
				cout << "Obrigado !" << endl;
				system("pause");
				break;
		default:
			cout << "Valor nao encontrado!" << endl;
			system("cls");
			desicao = IU.escolherFigura();
			break;
		}
	} while (desicao != 4);
}
