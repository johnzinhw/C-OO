#include <iostream>
using namespace std;
#include <string>
#include <conio.h>

void inverte(void);

int main()
{
	inverte();
	cout << endl;
	system("PAUSE");
	return 0;
}

void inverte(void)
{
	char ch;
	if ((ch = _getch ()) != '\r') inverte();
	cout << ch;
}