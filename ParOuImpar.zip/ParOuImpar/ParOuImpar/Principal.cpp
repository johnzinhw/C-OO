#include <iostream>
using namespace std;
#include <string>

class VerificadorDeParidade
{
private:
	int NumeroInteiro;
	string ImparPar;
public://declara��o dos m�todos
	VerificadorDeParidade();
	~VerificadorDeParidade();
	string verificarParidade(int);

};

int main(int argc, char *argv[]) //dentro do main s� fazer algo que interage com o usu�rio
{
	int UmInteiro;
	string sp; // string paridade
	VerificadorDeParidade vdp;  // instaciei um objeto
	
	
	cout << " Digite um numero inteiro : ";
	cin >> UmInteiro;

	
	sp = vdp.verificarParidade(UmInteiro); // chamei o metodo com a instancia��o do obj.
	cout << "O numero digitado e: " << sp << endl;

	system("PAUSE");
	return 0;
}

//defini��o do m�todo
VerificadorDeParidade::VerificadorDeParidade()
{

}

VerificadorDeParidade::~VerificadorDeParidade()
{

}

string VerificadorDeParidade::verificarParidade(int NumInteiro) // parte l�gica dentro do m�todo criado
{
	// como a classe est� como string, fazer uma variavel e retornar ela ...
	string UmaString;
	if (NumInteiro % 2 == 1)
	{
		UmaString = "Impar";

	}
	else
	{
		UmaString = "Par";
	}


	return UmaString;
}