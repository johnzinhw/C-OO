#include <iostream>
using namespace std;
#include <string>

// Local onde fica declara��es de classe

class ConversorRealDolar
{
private: // declaro atributos
    double ValorEmReal;
	double ValorEmDolar;
	double TaxaRealDolar;

public: // declaro m�todos
	ConversorRealDolar();
	~ConversorRealDolar();
	double converterR2D(double, double);
	};

int main( int argc, char * argv[] )
{

	double	UmValorReal = 0.0;
	double	Taxa = 0.0;
	double ValorEmDolar = 0.0;
	ConversorRealDolar crd;

	cout << "Entre com um valor em real: "; 
	cin >> UmValorReal;
	cout << "Entre com a taxa de conversao de real para d�lar: ";
	cin >> Taxa;

	ValorEmDolar = crd.converterR2D(UmValorReal , Taxa);

	cout << "-----------------------------" << endl;
	cout << "R$" << UmValorReal << " = " << "US$" << ValorEmDolar << endl;
	cout << "-----------------------------" << endl;

	system("pause");


	return 0;
}

// Defini��o dos m�todos, daqui para baixo

double ConversorRealDolar::converterR2D(double UmValorReal, double Taxa)
{
	double ValorEmDolar = 0.0;
	ValorEmDolar = UmValorReal * Taxa;
	return ValorEmDolar;
}

// construtor e destrutor

ConversorRealDolar::ConversorRealDolar() // iniciliazando os atributos do obj dentro do metodo construtor
{
	ValorEmReal = 0.0;
	ValorEmDolar = 0.0;
	TaxaRealDolar = 0.0;
}

ConversorRealDolar::~ConversorRealDolar()
{

}


