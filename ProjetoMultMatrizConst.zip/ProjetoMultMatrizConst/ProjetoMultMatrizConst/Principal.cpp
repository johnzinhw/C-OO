#include <iostream>
using namespace std;
#include <string>

class MatrizConstante
{
private:
	double Produto[2][4];
	int lin, col;
public:
	MatrizConstante ();
	~MatrizConstante();
	
};


int main(int argc, char * argv[]){
	
	double Produto[2][4];
	MatrizConstante mc;


	for (int i = 0; i < 2; i++)
	{
		string p1;
		if (i == 0)
		{
			p1 = "primeiro";
		}
		else{
			p1	 = "segundo";
		}
		cout << "Digite o preco do " << p1 << " produto: ";
		cin >> Produto[i][0];
		cout << endl;
	}

	for (int i = 0; i < 2; i++)
	{
		for (int j = 1; j <= 4; j++)
		{
			string p1;
			if (i == 0)
			{
				p1 = "primeiro";
			}
			else{
				p1 = "segundo";
			}
			cout << "Quantidade vendida do "<< i << " produto no dia " << j << ":" ;
			cin >> Produto[i][j];
			cout << endl;
		}
	}
	

	//system("PAUSE");
	return 0;
}

MatrizConstante::MatrizConstante()
{

}

MatrizConstante::~MatrizConstante()
{

}
