#include "InterfaceUsuario.h"


InterfaceUsuario::InterfaceUsuario()
{
	ValorRealLido = 0.0;
	ValorTaxaLida = 0.0;
	ValorDolarConvertido = 0.0;

}

InterfaceUsuario::~InterfaceUsuario()
{

}

void InterfaceUsuario::lerRealTaxa(double ValoresLidos[2])
{
	cout << "Entre com um valor em Real: ";
	cin >> ValoresLidos[0]; //Valor em Real em primeiro Lugar

	cout << "Entre com um valor de Taxa: ";
	cin >> ValoresLidos[1]; //Valor da Taxa em segundo lugar

	ValorRealLido = ValoresLidos[0];
	ValorTaxaLida = ValoresLidos[1];

}
void InterfaceUsuario::mostrarResultado(double ValorEmDolar)
{
	cout << "---------------------------------------" << endl;
	cout << "Valor convertido em dolar = US$" << ValorEmDolar << endl;
	cout << "---------------------------------------" << endl;
	ValorDolarConvertido = ValorEmDolar;
	
}