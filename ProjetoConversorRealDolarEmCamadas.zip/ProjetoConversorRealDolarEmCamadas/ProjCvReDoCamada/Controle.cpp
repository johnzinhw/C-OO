#include "Controle.h"

Controle::Controle()
{

}

Controle::~Controle()
{

}

void Controle::gerenciarExecucao(void)
{
	InterfaceUsuario iu;
	ConversorRealDolar crd;

	double OValorReal = 0.0,
		   OValorDaTaxa = 0.0,
		   OValorEmDolar = 0.0,
		   ValoresLidos[2] = { 0.0, 0.0 };

	iu.lerRealTaxa(ValoresLidos);
	OValorReal = ValoresLidos[0];
	OValorDaTaxa = ValoresLidos[1];

	OValorReal = iu.getValorRealLido();
	OValorDaTaxa = iu.getValorTaxaLida();

	OValorEmDolar = crd.converterR2D(OValorReal, OValorDaTaxa);

	iu.mostrarResultado(OValorEmDolar);


}