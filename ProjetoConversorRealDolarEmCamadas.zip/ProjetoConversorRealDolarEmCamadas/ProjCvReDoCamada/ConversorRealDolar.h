#include <iostream>
using namespace std;
#include <string>

class ConversorRealDolar
{
private: // declaro atributos
	double ValorEmReal;
	double ValorEmDolar;
	double TaxaRealDolar;

public: // declaro m�todos
	ConversorRealDolar();
	~ConversorRealDolar();
	double converterR2D(double, double);
};
