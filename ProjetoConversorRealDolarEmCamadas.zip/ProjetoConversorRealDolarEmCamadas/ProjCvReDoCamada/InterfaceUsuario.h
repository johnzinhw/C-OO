#include <iostream>
using namespace std;
#include <string>

class InterfaceUsuario
{
private:
	double ValorRealLido;
	double ValorTaxaLida;
	double ValorDolarConvertido;
public:
	InterfaceUsuario();
	~InterfaceUsuario();
	void lerRealTaxa(double[2]);  // enviando dois
	void mostrarResultado(double); //comportamento


	double getValorRealLido(void)
	{
		return ValorRealLido;
	}
	double getValorTaxaLida(void)
	{
		return ValorTaxaLida;
	}
};

