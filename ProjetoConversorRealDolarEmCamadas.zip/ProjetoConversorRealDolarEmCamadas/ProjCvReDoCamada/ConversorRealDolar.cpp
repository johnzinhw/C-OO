#include "ConversorRealDolar.h"

ConversorRealDolar::ConversorRealDolar() // iniciliazando os atributos do obj dentro do metodo construtor
{
	ValorEmReal = 0.0;
	ValorEmDolar = 0.0;
	TaxaRealDolar = 0.0;
}

ConversorRealDolar::~ConversorRealDolar()
{

}

double ConversorRealDolar::converterR2D(double UmValorReal, double Taxa)
{
	ValorEmReal = UmValorReal;
	TaxaRealDolar = Taxa;

	double ValorEmDolar = 0.0;
	ValorEmDolar = UmValorReal * Taxa;

	ValorEmDolar = ValorEmDolar;
	return ValorEmDolar;
}