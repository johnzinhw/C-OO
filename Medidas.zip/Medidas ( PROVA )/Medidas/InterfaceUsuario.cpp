#include "InterfaceUsuario.h"


InterfaceUsuario::InterfaceUsuario()
{
}


InterfaceUsuario::~InterfaceUsuario()
{
}

int InterfaceUsuario::mostrarMenu(void)
{
	int Opcao = 0;

	cout << endl;
	cout << "	- Escolha uma opcao -" << endl;
	cout << "	1 - Converter comprimentos" << endl;
	cout << "	2 - Converter massas" << endl;
	cout << "	3 - Encerrar" << endl;
	cout << "	Opcao escolhida: ";
	cin >> Opcao;
	cout << endl;
	return Opcao;
}

double InterfaceUsuario::lerComprimento(void)
{
	double Comprimento;
	cout << endl;
	cout << "Entre com o comprimento em metros: ";
	cin >> Comprimento;
	cout << endl;
	return Comprimento;
}

double InterfaceUsuario::lerMassa(void)
{
	double Massa;
	cout << endl;
	cout << "Entre com a massa em gramas: ";
	cin >> Massa;
	cout << endl;
	return Massa;
}

void InterfaceUsuario::mostrarValores1(double OsComprimentos[3])
{
	cout << "Valor em decimetro = " << OsComprimentos[0] << "[dm]" << endl;
	cout << "Valor em centimetro = " << OsComprimentos[1] << "[cm]" << endl;
	cout << "Valor em milimetro = " << OsComprimentos[2] << "[mm]" << endl;
}

void InterfaceUsuario::mostrarValores2(double AsMassas[3])
{
	cout << "Valor em decigrama = " << AsMassas[0] << "[dg]" << endl;
	cout << "Valor em centigrama = " << AsMassas[1] << "[cg]" << endl;
	cout << "Valor em miligrama = " << AsMassas[2] << "[mg]" << endl;
}