#include "Controle.h"


Controle::Controle()
{
}


Controle::~Controle()
{
}

void Controle::gerenciarExecucao(void)
{
	InterfaceUsuario iu;
	ConversorDeComprimentos cdc;
	ConversorDeMassas cdm;

	int Opcao = 0;
	double Metros, Gramas;
	double OsComprimentos[3] = { 0.0, 0.0, 0.0 },
		AsMassas[3] = { 0.0, 0.0, 0.0 };

	do
	{
		Opcao = iu.mostrarMenu();
		if (Opcao == 1)
		{
			Metros = iu.lerComprimento();
			cdc.converterComprimentos(Metros,OsComprimentos);
			iu.mostrarValores1(OsComprimentos);
			system("pause");
		}
		else if (Opcao == 2)
		{
			Gramas = iu.lerMassa();
			cdm.converterMassas(Gramas,AsMassas);
			iu.mostrarValores2(AsMassas);
			system("pause");
		}
		system("cls");
	} while (Opcao != 3);
}