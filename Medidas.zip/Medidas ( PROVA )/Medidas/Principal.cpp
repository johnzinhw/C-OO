#include "Controle.h"

int main(int argc, char * argv[])
{
	Controle controle;
	controle.gerenciarExecucao();
	return 0;
}