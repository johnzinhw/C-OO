#ifndef InterfaceUsuarioH
#define InterfaceUsuarioH

#include <iostream>
using namespace std;
#include <string>

class InterfaceUsuario
{
public:
	InterfaceUsuario();
	~InterfaceUsuario();
	int mostrarMenu(void);
	double lerComprimento(void);
	double lerMassa(void);
	void mostrarValores1(double[3]);
	void mostrarValores2(double[3]);

};

#endif