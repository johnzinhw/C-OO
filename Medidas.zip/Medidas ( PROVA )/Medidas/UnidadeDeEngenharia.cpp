#include "UnidadeDeEngenharia.h"


UnidadeDeEngenharia::UnidadeDeEngenharia()
{
	Valor = 0.0;
	ValoresConvertidos[0] = 0.0;
	ValoresConvertidos[1] = 0.0;
	ValoresConvertidos[2] = 0.0;
}


UnidadeDeEngenharia::~UnidadeDeEngenharia()
{
}

void UnidadeDeEngenharia::setValor(double UmValor)
{
	Valor = UmValor;
}

double UnidadeDeEngenharia::getValor(void)
{
	return Valor;
}

void UnidadeDeEngenharia::setValores(double OsValores[3])
{
	for (int i = 0; i < 3; i++)
	{
		ValoresConvertidos[i] = OsValores[i];
	}
}

double UnidadeDeEngenharia::getValores1(void)
{
	return ValoresConvertidos[0];
}

double UnidadeDeEngenharia::getValores2(void)
{
	return ValoresConvertidos[1];
}

double UnidadeDeEngenharia::getValores3(void)
{
	return ValoresConvertidos[2];
}

void UnidadeDeEngenharia::realizarConversao(void)
{
	ValoresConvertidos[0] = Valor * 10;
	ValoresConvertidos[1] = Valor * 100;
	ValoresConvertidos[2] = Valor * 1000;
}