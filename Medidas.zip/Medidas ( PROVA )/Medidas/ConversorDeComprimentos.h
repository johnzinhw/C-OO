#ifndef ConversorDeComprimentosH
#define ConversorDeComprimentosH

#include "UnidadeDeEngenharia.h"

class ConversorDeComprimentos : public UnidadeDeEngenharia
{
private:
protected:
public:
	ConversorDeComprimentos();
	~ConversorDeComprimentos();
	void converterComprimentos(double, double[3]);
};

#endif