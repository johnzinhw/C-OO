#ifndef ConversorDeMassasH
#define ConversorDeMassasH

#include "UnidadeDeEngenharia.h"

class ConversorDeMassas: public UnidadeDeEngenharia
{
private:
protected:
public:
	ConversorDeMassas();
	~ConversorDeMassas();
	void converterMassas(double, double[3]);
};

#endif