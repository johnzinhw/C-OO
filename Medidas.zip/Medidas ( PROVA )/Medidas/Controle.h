#ifndef ControleH
#define ControleH

#include <iostream>
using namespace std;
#include <string>
#include "InterfaceUsuario.h"
#include "ConversorDeComprimentos.h"
#include "ConversorDeMassas.h"

class Controle
{
public:
	Controle();
	~Controle();
	void gerenciarExecucao(void);
};

#endif