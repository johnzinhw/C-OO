#include "ConversorDeMassas.h"


ConversorDeMassas::ConversorDeMassas()
{
}


ConversorDeMassas::~ConversorDeMassas()
{
}

void ConversorDeMassas::converterMassas(double UmValor, double Massas[3])
{
	setValor(UmValor);
	realizarConversao();

	Massas[0] = getValores1();
	Massas[1] = getValores2();
	Massas[2] = getValores3();
}