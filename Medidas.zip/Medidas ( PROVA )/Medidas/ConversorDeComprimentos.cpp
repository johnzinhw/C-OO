#include "ConversorDeComprimentos.h"


ConversorDeComprimentos::ConversorDeComprimentos()
{
}


ConversorDeComprimentos::~ConversorDeComprimentos()
{
}

void ConversorDeComprimentos::converterComprimentos(double UmValor, double Comprimentos[3])
{
	setValor(UmValor);
	realizarConversao();

	Comprimentos[0] = getValores1();
	Comprimentos[1] = getValores2();
	Comprimentos[2] = getValores3();
}