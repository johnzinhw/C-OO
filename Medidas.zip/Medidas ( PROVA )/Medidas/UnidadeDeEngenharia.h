#ifndef UnidadeDeEngenhariaH
#define UnidadeDeEngenhariaH

#include <iostream>
using namespace std;
#include <string>

class UnidadeDeEngenharia
{
private:
	double Valor;
	double ValoresConvertidos[3];
public:
	UnidadeDeEngenharia();
	~UnidadeDeEngenharia();
	void setValor(double);
	double getValor(void);
	void setValores(double[3]);
	double getValores1(void);
	double getValores2(void);
	double getValores3(void);
	void realizarConversao(void);
};

#endif