#ifndef SimuladorH
#define SimuladorH
//------------------------------
#include <iostream>
using namespace std;
#include <string>
#include <time.h>
#include <stdlib.h>

#define N 15

class Simulador
{
private:
	string  MesDoSorteio, LocalidadeDoSorteio;
	int DiaDoSorteio, Acertos, Jogo[N], Sorteio[N];
public:
	Simulador();
	~Simulador();
protected:
	void SetDia(int);
	void SetMes(string);
	void SetLocal(string);
	void SetAcertos(int);
	void SetJogo(int[N]);
	void SetSorteio(int[N]);
	int GetDia();
	string GetMes();
	string GetLocal();
	int GetAcertos();
	int GetJogo();
	int GetSorteio();
};


//------------------------------
#endif