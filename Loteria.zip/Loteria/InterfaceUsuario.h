#ifndef InterfaceUsuarioH
#define InterfaceUsuarioH
//------------------------------
#include <iostream>
using namespace std;
#include <string>

#define N 15

class InterfaceUsuario
{
private:
	int TipoDeSorteio, JogoFeito[N], QuantidadeAcertos;
public:
	InterfaceUsuario();
	~InterfaceUsuario();
	int lerOpcao(void);
	void lerJogoMega(int[N]);
	void lerJogoLoto(int[N]);
	void mostrarResultadoMega(int, string, string, int[6], int[6], int);
	void mostrarResultadoLoto(int, string, string, int[6], int[6], int);

	
	
};
//------------------------------
#endif