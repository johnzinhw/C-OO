#include "InterfaceUsuario.h"

InterfaceUsuario::InterfaceUsuario()
{
	TipoDeSorteio = 0;
	QuantidadeAcertos = 0;
	for (int i = 0; i < N; ++i)
	{
		JogoFeito[i] = 0;
	}
}
InterfaceUsuario::~InterfaceUsuario()
{

}
int InterfaceUsuario::lerOpcao(void)
{
	system("cls");
	int Opcao;
	do{
		system("cls");
		cout << "\t\tPROGRAMA QUE SIMULA O SORTEIO DA LOTERIA"<< endl <<"1. MegaSena" << endl << "2. LotoFacil" << endl << "3. Sair" << endl;
		cout << "Digite a Opcao desejada" << endl;
		cin >> Opcao;
	} while (Opcao < 1 && Opcao > 3);
	TipoDeSorteio = Opcao;
	return Opcao;
}
void InterfaceUsuario::lerJogoMega(int Jogo[N])
{
	system("cls");
	for (int i = 0; i < 6; ++i)
	{
		//loop para verificar se o numero digitado existe ou n�o

		cout << "Digite o " << i + 1 << " numero" << endl;
		cin >> JogoFeito[i];
		while (JogoFeito[i] < 0 || JogoFeito[i] > 60)
		{
			cout << "Numero digitado n�o valido!!!!" << endl;
			cout << "Digite um numero entre 1 e 60: " << endl;
			cin >> JogoFeito[i];
		}

	}//fim do for
	//loop para verificar se existe algum numero repetido jogado
	for (int i = 0; i < 6; ++i)
	{
		for (int j = i + 1; j < 6; ++j)
		{
			if (JogoFeito[i] == JogoFeito[j])
			{
				cout << "O valor " << JogoFeito[i] << " foi repetido, por favor digite um valor diferente : " << endl;
				cin >> JogoFeito[i];
			}
		}
	}
	for (int i = 0; i < N; ++i)
	{
		Jogo[i] = JogoFeito[i];
	}
}
void InterfaceUsuario::lerJogoLoto(int Jogo[N])
{
	system("cls");
	for (int i = 0; i < N; ++i)
	{
		//loop para verificar se o numero digitado existe ou n�o

		cout << "Digite o " << i + 1 << " numero" << endl;
		cin >> JogoFeito[i];
		while (JogoFeito[i] < 0 || JogoFeito[i] > 25)
		{
			cout << "Numero digitado n�o valido!!!!" << endl;
			cout << "Digite um numero entre 0 e 25: " << endl;
			cin >> JogoFeito[i];
		}

	}//fim do for
	//loop para verificar se existe algum numero repetido jogado
	for (int i = 0; i < N; ++i)
	{
		for (int j = i + 1; j < N; ++j)
		{
			if (JogoFeito[i] == JogoFeito[j])
			{
				cout << "O valor " << JogoFeito[i] << " foi repetido, por favor digite um valor diferente : " << endl;
				cin >> JogoFeito[i];
			}
		}
	}
	for (int i = 0; i < N; ++i)
	{
		Jogo[i] = JogoFeito[i];
	}
}
void InterfaceUsuario::mostrarResultadoMega(int DiaSorteado, string MesSorteado, string LocalSorteado, int Jogo[N], int Sorteados[N], int NumAcertos)
{
	system("cls");
	cout << "Numeros Sorteados: ";
	for(int i = 0; i < 6; ++i)
	{
		cout << Sorteados[i] << "; ";
	}

	cout << endl << endl << "Numeros Jogados: ";
	for(int i = 0; i < 6; ++i)
	{
		cout << Jogo[i] << "; ";
	}

	cout << endl << endl << "Numero de Acertos: " << NumAcertos << endl;
	cout << endl << "Local Do Sorteio: " << LocalSorteado << endl << endl << "Data Do Sorteio: " << DiaSorteado<< "/" << MesSorteado <<"/2015" << endl;
	system("pause");
}
void InterfaceUsuario::mostrarResultadoLoto(int DiaSorteado, string MesSorteado, string LocalSorteado, int Jogo[N], int Sorteados[N], int NumAcertos)
{
	system("cls");
	cout << "Numeros Sorteados: ";
	for (int i = 0; i < N; ++i)
	{
		cout << Sorteados[i] << "; ";
	}

	cout << endl << endl << "Numeros Jogados: ";
	for (int i = 0; i < N; ++i)
	{
		cout << Jogo[i] << "; ";
	}

	cout << endl << endl << "Numero de Acertos: " << NumAcertos << endl;
	cout << endl << "Local Do Sorteio: " << LocalSorteado << endl << endl << "Data Do Sorteio: " << DiaSorteado << "/" << MesSorteado << "/2015" << endl;
	system("pause");
}