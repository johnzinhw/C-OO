#include "Lotofacil.h"

Lotofacil::Lotofacil()
{
	Acertos = 0;
	Dia = 0;
	Mes = "Janeiro";
	Local = "Pedralva";
	for (int i = 0; i < N; ++i)
	{
		NumerosSorteados[N] = 0;
	}
}
Lotofacil::~Lotofacil()
{

}
string Lotofacil::definirMeses(int indice)
{
	//define um vetor de strings que contem todos os mese do ano
	//retorna o mes sorteado definido pelo indice sorteado
	string Mes[12];
	string MesSorteado;
	Mes[0] = "Janeiro";
	Mes[1] = "Fevereiro";
	Mes[2] = "Marcio";
	Mes[3] = "Abril";
	Mes[4] = "Maio";
	Mes[5] = "Junho";
	Mes[6] = "Julho";
	Mes[7] = "Agosto";
	Mes[8] = "Setembro";
	Mes[9] = "Outubro";
	Mes[10] = "Novembro";
	Mes[11] = "Dezembro";
	MesSorteado = Mes[indice];
	return MesSorteado;
}
string Lotofacil::definirlocalidade(int indice)
{
	//define um vetor de string que contem algumas localidade
	//retorna o local sorteado definido pelo indice sorteado 
	string Local[5];
	string LocalSorteado;
	Local[0] = "Pedralva";
	Local[1] = "Itajuba-MG";
	Local[2] = "Congonhal-MG";
	Local[3] = "Cristina-MG";
	Local[4] = "Cataguases-MG";

	LocalSorteado = Local[indice];
	return LocalSorteado;
}
int Lotofacil::sortearDia()
{
	//faz o sorteio do dia em que sera feito o sorteio da loteria 
	srand(time(NULL));
	Dia = (rand() % 30) + 1;
	return Dia;
}
string Lotofacil::sortearMes()
{
	//faz o sorteio do mes em que sera feito o sorteio da loteria
	srand(time(NULL));
	int indice = (rand() % 11) + 1;
	Mes = definirMeses(indice);
	return Mes;
}
string Lotofacil::sortearLocalidade()
{
	//faz o sorteio da localidade em que sera feito o sorteio da loteria
	srand(time(NULL));
	int indice = (rand() % 5) + 1;
	Local = definirlocalidade(indice);
	return Local;
}

void Lotofacil::sortearJogo(int Sorteado[N])
{
	srand(time(NULL));
	int Sorteio;

	for (int i = 0; i < N; ++i)
	{
		NumerosSorteados[i] = (rand() % 26);
	}

	verificarRepetidos();
	ordenarNumeros();

	for (int i = 0; i < N; ++i)
	{
		Sorteado[i] = NumerosSorteados[i];
	}

}
void Lotofacil::verificarRepetidos(void)
{
	//verifica se h� algum numero repetido sorteado, se sim 
	//sorteia novamente e recome�a a verifica��o
	for (int i = 0; i < N; i++)
	{
		for (int j = i + 1; j < N; j++)
		{
			if (NumerosSorteados[i] == NumerosSorteados[j])
			{
				NumerosSorteados[i] = (rand() % 26);
				i = -1;
			}
		}
	}
}
void Lotofacil::ordenarNumeros(void)
{
	int Aux = 0;
	//este m�todo ordena todos os numeros que foram sorteado.
	for (int i = 0; i < N; ++i)
	{
		for (int j = 0; j < N - 1; ++j)
		{
			if (NumerosSorteados[j] > NumerosSorteados[j + 1])
			{
				Aux = NumerosSorteados[j + 1];
				NumerosSorteados[j + 1] = NumerosSorteados[j];
				NumerosSorteados[j] = Aux;
			}//fim do if
		}//fim do for filho
	}//fim do for pai
}
int Lotofacil::compararJogo(int Jogo[N])
{
	//este m�todo compara cada n�mero jogado com todos os numeros sorteados, para verificar se h� algum igual, se sim
	//a vari�vel Acertos � imcrementada em 1
	Acertos = 0;
	for (int i = 0; i < N; i++)
	{
		for (int j = 0; j < N; j++)
		{
			
			if (Jogo[i] == NumerosSorteados[j])
			{
				Acertos++;
			}//fim do if
		}//fim do for filho
	}//fim do for pai
	return Acertos;
}



