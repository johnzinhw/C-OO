#ifndef MegaSenaH
#define MegaSenaH
//------------------------------

#include "Simulador.h"

class MegaSena :public Simulador
{
private:
	int Acertos,Dia,NumerosSorteados[N];
	string Mes, Local;
	string definirMeses(int);
	string definirlocalidade(int);
	void ordenarNumeros(void);
	void verificarRepetidos(void);
public:
	MegaSena();
	~MegaSena();
	int sortearDia();
	string sortearMes();
	string sortearLocalidade();
	void sortearJogo(int[N]);
	int compararJogo(int[N]);
};

//------------------------------
#endif