#include "Controle.h"

Controle::Controle()
{

}

Controle::~Controle()
{

}

void Controle::gerenciarExecucao(void)
{
	int Opcao,DiaSorteado,Jogo[N],Sorteado[N],NumAcertos;
	string MesSorteado, LocalSorteado;

	InterfaceUsuario iu;
	MegaSena mega;
	Lotofacil loto;
	
	do
	{
		Opcao = iu.lerOpcao();

		switch (Opcao)
		{
		case 1: //megasena
			iu.lerJogoMega(Jogo);
			DiaSorteado = mega.sortearDia();
			MesSorteado = mega.sortearMes();	
			LocalSorteado = mega.sortearLocalidade();
			mega.sortearJogo(Sorteado);
			NumAcertos = mega.compararJogo(Jogo);
			iu.mostrarResultadoMega(DiaSorteado, MesSorteado, LocalSorteado, Jogo, Sorteado, NumAcertos);
			break;
		case 2: //lotofacil
			iu.lerJogoLoto(Jogo);
			DiaSorteado = loto.sortearDia();
			MesSorteado = loto.sortearMes();
			LocalSorteado = loto.sortearLocalidade();
			loto.sortearJogo(Sorteado);
			NumAcertos = loto.compararJogo(Jogo);
			iu.mostrarResultadoLoto(DiaSorteado, MesSorteado, LocalSorteado, Jogo, Sorteado, NumAcertos);
			break;
		}
	} while (Opcao != 3);
}