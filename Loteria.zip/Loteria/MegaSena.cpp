#include "MegaSena.h"

MegaSena::MegaSena()
{
	Acertos = 0;
	Dia = 0;
	Mes = "Janeiro";
	Local = "Pedralva"; 
	for (int i = 0; i < N; ++i)
	{
		NumerosSorteados[N] = 0;
	}
}
MegaSena::~MegaSena()
{
	
}
string MegaSena::definirMeses(int indice)
{
	string Mes[12];
	string MesSorteado;
	Mes[0] = "Janeiro";
	Mes[1] = "Fevereiro";
	Mes[2] = "Marcio";
	Mes[3] = "Abril";
	Mes[4] = "Maio";
	Mes[5] = "Junho";
	Mes[6] = "Julho";
	Mes[7] = "Agosto";
	Mes[8] = "Setembro";
	Mes[9] = "Outubro";
	Mes[10] = "Novembro";
	Mes[11] = "Dezembro";
	MesSorteado = Mes[indice];
	return MesSorteado;
}
string MegaSena::definirlocalidade(int indice)
{
	string Local[5];
	string LocalSorteado;
	Local[0] = "Pedralva";
	Local[1] = "Itajuba-MG";
	Local[2] = "Congonhal-MG";
	Local[3] = "Cristina-MG";
	Local[4] = "Cataguases-MG";

	LocalSorteado = Local[indice];
	return LocalSorteado;
}
int MegaSena::sortearDia()
{
	srand(time(NULL));
	Dia = (rand() % 30) + 1;
	return Dia;
}
string MegaSena::sortearMes()
{
	srand(time(NULL));
	int indice = (rand() % 11) + 1;
	Mes = definirMeses(indice);
	return Mes;
}
string MegaSena::sortearLocalidade()
{
	srand(time(NULL));
	int indice = (rand() % 5) + 1;
	Local = definirlocalidade(indice);
	return Local;
}

void MegaSena::sortearJogo(int Sorteado[N])
{
	srand(time(NULL));
	int Sorteio;

	for (int i = 0; i < N; ++i)
	{
		NumerosSorteados[i] = (rand() % 60) + 1;
	}

	verificarRepetidos();
	ordenarNumeros();

	for (int i = 0; i < 6; ++i)
	{
		Sorteado[i] = NumerosSorteados[i];
	}

}
void MegaSena::verificarRepetidos(void)
{
	for (int i = 0; i < N; i++)
	{
		for (int j = i + 1; j < N; j++)
		{
			if (NumerosSorteados[i] == NumerosSorteados[j])
			{
				NumerosSorteados[i] = (rand() % 60) + 1;
				i = -1;
			}
		}
	}
}
void MegaSena::ordenarNumeros(void)
{
	int Aux = 0;
	//este m�todo ordena todos os numeros no vetor de N posicoes.
	for (int i = 0; i < N; ++i)
	{
		for (int j = 0; j < N - 1; ++j)
		{
			if (NumerosSorteados[j] > NumerosSorteados[j + 1])
			{
				Aux = NumerosSorteados[j + 1];
				NumerosSorteados[j + 1] = NumerosSorteados[j];
				NumerosSorteados[j] = Aux;
			}//fim do if
		}//fim do for filho
	}//fim do for pai
}
int MegaSena::compararJogo(int Jogo[6])
{
	//este m�todo compara cada n�mero jogado com todos os numeros sorteados, para verificar se h� algum igual, se sim
	//a vari�vel Acertos � imcrementada em 1
	Acertos = 0;
	for (int i = 0; i < 6; i++)
	{
		for (int j = 0; j < 6; j++)
		{
			if (Jogo[i] == NumerosSorteados[j])
			{
				Acertos++;
			}//fim do if
		}//fim do for filho
	}//fim do for pai
	return Acertos;
}
