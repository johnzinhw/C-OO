#include "Simulador.h"

Simulador::Simulador()
{
	for (int i = 0; i < N; ++i)
	{
		Jogo[N] = 0;
		Sorteio[N] = 0;
	}
	DiaDoSorteio = 0;
	Acertos = 0; 
	MesDoSorteio = "Janeiro";
	LocalidadeDoSorteio = "Pedralva-MG";
}
Simulador::~Simulador()
{

}
void Simulador::SetDia(int DiaSorteado)
{
	DiaDoSorteio = DiaSorteado;
	
}
void Simulador::SetMes(string MesSorteado)
{
	MesDoSorteio = MesSorteado;
}
void Simulador::SetLocal(string LocalSorteado)
{
	LocalidadeDoSorteio = LocalSorteado;
}
void Simulador::SetAcertos(int QtdAcertos)
{
	Acertos = QtdAcertos;
}
void Simulador::SetJogo(int JogoFeito[N])
{
	for (int i = 0; i < N; ++i)
	{
		Jogo[N] = JogoFeito[N];
	}
}
void Simulador::SetSorteio(int NumerosSorteados[N])
{
	for (int i = 0; i < N; ++i)
	{
		Sorteio[N] = NumerosSorteados[N];
	}
}
int Simulador::GetDia()
{
	return DiaDoSorteio;
}
string Simulador::GetMes()
{
	return MesDoSorteio;
}
string Simulador::GetLocal()
{
	return LocalidadeDoSorteio;
}
int Simulador::GetAcertos()
{
	return Acertos;
}
int Simulador::GetJogo()
{
	return Jogo[N];
}
int Simulador::GetSorteio()
{
	return 	Sorteio[N];
}