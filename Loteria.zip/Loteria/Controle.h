#ifndef ControleH
#define ControleH
//----------------------------------------
#include "InterfaceUsuario.h"
#include "Lotofacil.h"
#include "MegaSena.h"

class Controle
{
private:
public:
	Controle();
	~Controle();
	void gerenciarExecucao(void);
};
//------------------------------------------
#endif