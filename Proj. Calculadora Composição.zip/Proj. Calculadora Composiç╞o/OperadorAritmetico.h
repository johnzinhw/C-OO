#ifndef OperadorAritmeticoH
#define OperadorAritmeticoH
//-----------------------------
#include <iostream>
using namespace std;
#include <string>

class OperadorAritmetico
{
private:
public:
	OperadorAritmetico();
	~OperadorAritmetico();
	void calcular4Operacoes(float[3], float[4]);
};
//-----------------------------
#endif