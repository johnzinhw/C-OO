#include "Controle.h"

Controle::Controle()
{

}

Controle::~Controle()
{

}

void Controle::gerenciarExecucao(void)
{
	InterfaceUsuario	iu;
	Calculadora			calc;

	float	Dados[3] = { 0.0, 0.0, 0.0 }, 
		ResultadosAritmeticos[4] = {0.0, 0.0, 0.0, 0.0}, 
		ResultadosTrigonometricos[3] = {0.0, 0.0, 0.0};

	int UmaOpcao = 0;

	while (true)
	{
		UmaOpcao = iu.lerDados(Dados);
		if (UmaOpcao == 1)
		{
			calc.fazerCalculoAritmetico(Dados, ResultadosAritmeticos);
			iu.mostrarResultadoAritmetico(ResultadosAritmeticos);
			continue;
		}
		else if (UmaOpcao == 2)
		{
			calc.fazerCalculoTrigonometrico(Dados[2], ResultadosTrigonometricos);
			iu.mostrarResultadoTrigonometrico(ResultadosTrigonometricos);
			continue;
		}
		else if (UmaOpcao == 3)
			break;
			
	}

}