#ifndef InterfaceusuarioH
#define InterfaceUsuarioH
//--------------------------------------
#include <iostream>
using namespace std;
#include <string>

class InterfaceUsuario
{
private:
	int Opcao;
	float Operando1, Operando2, Angulo;
	float ResultadoAritmetico[4], 
		  ResultadoTrigonometrico[3];
	void	lerOperandos(float [3]);
	void	lerAngulo(float [3]);
public:
	InterfaceUsuario();
	~InterfaceUsuario();
	int		lerDados(float [3]);
	void	mostrarResultadoAritmetico(float [4]);
	void	mostrarResultadoTrigonometrico(float [3]);
};
//--------------------------------------
#endif