#ifndef OperadorTrigonometricoH
#define OperadorTrigonometricoH
//------------------------------
#include <iostream>
using namespace std;
#include <string>

class OperadorTrigonometrico
{
private:
public:
	OperadorTrigonometrico();
	~OperadorTrigonometrico();
	void calcularGrandezasTrigonometricas(float, float[3]);
};
//------------------------------
#endif