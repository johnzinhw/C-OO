#include "OperadorTrigonometrico.h"

OperadorTrigonometrico::OperadorTrigonometrico()
{

}

OperadorTrigonometrico::~OperadorTrigonometrico()
{

}

void OperadorTrigonometrico::calcularGrandezasTrigonometricas(float UmAngulo,
	float ResultadosTrigonometricos[3])
{
	ResultadosTrigonometricos[0] = (float)sin((double)UmAngulo);
	ResultadosTrigonometricos[1] = (float)cos((double)UmAngulo);
	ResultadosTrigonometricos[2] = (float)tan((double)UmAngulo);
}