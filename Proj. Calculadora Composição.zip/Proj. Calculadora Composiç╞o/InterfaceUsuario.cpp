#include "InterfaceUsuario.h"

InterfaceUsuario::InterfaceUsuario()
{
	Opcao = 0;
	Operando1 = 0.0;
	Operando2 = 0.0;
	for (int i = 0; i < 4; ++i)
		ResultadoAritmetico[i] = 0.0;
	for (int i = 0; i < 3; ++i)
		ResultadoTrigonometrico[i] = 0.0;
}

InterfaceUsuario::~InterfaceUsuario()
{

}

int InterfaceUsuario::lerDados(float OsDados[3])
{

	cout << "Voce deseja:" << endl;
	cout << "1. Fazer operacoes aritmeticas." << endl;
	cout << "2. Fazer operacoes trigonometricas." << endl;
	cout << "3. Encerrar a execucao do programa." << endl;
	cin >> Opcao;

	switch (Opcao)
	{
	case 1:
		lerOperandos(OsDados);
		break;
	case 2:
		lerAngulo(OsDados);
		break;
	case 3:
		break;
	default:
		cout << "Opcao invalida!" << endl;
		break;
	}
	return Opcao;
}

void InterfaceUsuario::lerOperandos(float OsDados[3])
{
	cout << "Entre com o primeiro operando: ";
	cin >> OsDados[0];
	Operando1 = OsDados[0];

	cout << "Entre com o segundo operando: ";
	cin >> OsDados[1];
	Operando2 = OsDados[1];

	OsDados[2] = 0.0;
	cout << endl;
}

void InterfaceUsuario::lerAngulo(float OsDados[3])
{
	cout << "Entre com um angulo em graus:";
	cin >> OsDados[2];
	Angulo = OsDados[2];
	OsDados[0] = 0.0;
	OsDados[1] = 0.0;
}

void InterfaceUsuario::mostrarResultadoAritmetico(float OResultadoAritmetico[4])
{
	cout << "Resultado das operacoes aritmeticas:" << endl;
	cout << "--------------------------------------------------" << endl;
	cout << "Resultado da soma          = " << OResultadoAritmetico[0] << endl;
	cout << "Resultado da subtracao     = " << OResultadoAritmetico[1] << endl;
	cout << "Resultado da multiplicacao = " << OResultadoAritmetico[2] << endl;
	cout << "Resultado da divisao       = " << OResultadoAritmetico[3] << endl;
	cout << "--------------------------------------------------" << endl;

	system("pause");

	for (int i = 0; i < 4; ++i)
		ResultadoAritmetico[i] = OResultadoAritmetico[i];
}

void InterfaceUsuario::mostrarResultadoTrigonometrico(float OResultadoTrigonometrico[3])
{
	cout << "Resultados das operacoes trigonometricas:" << endl;
	cout << "--------------------------------------------------" << endl;
	cout << "Seno     = " << OResultadoTrigonometrico[0] << endl;
	cout << "Coseno   = " << OResultadoTrigonometrico[1] << endl;
	cout << "Tangente = " << OResultadoTrigonometrico[2] << endl;
	cout << "--------------------------------------------------" << endl;

	system("pause");

	for (int i = 0; i  < 3; ++i)
		ResultadoTrigonometrico[i] = OResultadoTrigonometrico[i];
}
