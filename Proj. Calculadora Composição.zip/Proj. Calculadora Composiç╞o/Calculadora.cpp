#include "Calculadora.h"

Calculadora::Calculadora() : oa(), ot()
{
	for (int i = 0; i < 2; ++i)
		OperandosAritmeticos[i] = 0.0;
	Angulo = 0.0;
	for (int i = 0; i < 4; ++i)
		ResultadoOperacaoAritmetica[i] = 0.0;
	for (int i = 0; i < 3; ++i)
		ResultadoOperacaoTrigonometrica[i] = 0.0;
}

Calculadora::~Calculadora()
{
	
}

void Calculadora::fazerCalculoAritmetico(float OperandosAritmeticos[3],
	float ResultadosAritmeticos[4])
{
	oa.calcular4Operacoes(OperandosAritmeticos, ResultadosAritmeticos);
}

void Calculadora::fazerCalculoTrigonometrico(float UmAngulo,
											 float ResultadosTrigonometricos[3])
{
	ot.calcularGrandezasTrigonometricas(UmAngulo, ResultadosTrigonometricos);
}
