#ifndef CalculadoraH
#define CalculadoraH
//----------------------------
#include <iostream>
using namespace std;
#include <string>

#include "OperadorAritmetico.h"
#include "OperadorTrigonometrico.h"

class Calculadora
{
private:
	OperadorAritmetico		oa;
	OperadorTrigonometrico	ot;
	float OperandosAritmeticos[2];
	float Angulo;
	float ResultadoOperacaoAritmetica[4];
	float ResultadoOperacaoTrigonometrica[3];
public:
	Calculadora();
	~Calculadora();
	void fazerCalculoAritmetico(float[3], float[4]);
	void fazerCalculoTrigonometrico(float, float[3]);
};
//----------------------------
#endif