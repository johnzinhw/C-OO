#include "OperadorAritmetico.h"

OperadorAritmetico::OperadorAritmetico()
{

}

OperadorAritmetico::~OperadorAritmetico()
{

}

void OperadorAritmetico::calcular4Operacoes(float Operandos[3], float Resultados[4])
{
	Resultados[0] = Operandos[0] + Operandos[1];
	Resultados[1] = Operandos[0] - Operandos[1];
	Resultados[2] = Operandos[0] * Operandos[1];
	Resultados[3] = Operandos[0] / Operandos[1];
}
