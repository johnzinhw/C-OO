#ifndef ControleH
#define ControleH
//------------------------------------
#include "InterfaceUsuario.h"
#include "Pilha.h"

class Controle
{
private:
public:
	Controle();
	~Controle();
	void gerenciarExecucao(void);
};

//------------------------------------
#endif